package com.happyholiday.action;

import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;

@ParentPackage(value = "userPackage")
@Namespace("/")
public class UserBaseAction extends BaseAction {
	

}
