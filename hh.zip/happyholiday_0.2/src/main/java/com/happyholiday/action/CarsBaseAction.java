package com.happyholiday.action;

import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;

@ParentPackage(value = "carsPackage")
@Namespace("/")
public class CarsBaseAction extends BaseAction{
	
	
}
