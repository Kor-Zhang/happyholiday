package com.happyholiday.action;

import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;

@ParentPackage(value = "viewsTicketsPackage")
@Namespace("/")
public class ViewsTicketsBaseAction extends BaseAction{
	
}
