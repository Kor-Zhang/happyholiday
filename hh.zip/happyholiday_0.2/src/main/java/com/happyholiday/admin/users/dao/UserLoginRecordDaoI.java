package com.happyholiday.admin.users.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.Userloginrecord;

public interface UserLoginRecordDaoI extends BaseDaoI<Userloginrecord>{
	
}
