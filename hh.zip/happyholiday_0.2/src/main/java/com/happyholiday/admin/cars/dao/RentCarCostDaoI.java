package com.happyholiday.admin.cars.dao;

import java.io.Serializable;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.Admins;
import com.happyholiday.model.Rentcarcost;

public interface RentCarCostDaoI extends BaseDaoI<Rentcarcost>{
	
}
