package com.happyholiday.admin.exception;

public class AdminsException extends Exception {

	public AdminsException() {
		super();
	}

	public AdminsException(String message) {
		super(message);
	}
	
}
