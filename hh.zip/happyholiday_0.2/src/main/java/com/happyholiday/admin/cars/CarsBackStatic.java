package com.happyholiday.admin.cars;

import java.io.File;

import com.happyholiday.admin.BackStatic;

public class CarsBackStatic extends BackStatic{
	
}
