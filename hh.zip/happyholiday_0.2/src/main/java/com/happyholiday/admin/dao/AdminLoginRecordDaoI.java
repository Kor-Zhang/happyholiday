package com.happyholiday.admin.dao;

import java.io.Serializable;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.Adminloginrecord;

public interface AdminLoginRecordDaoI extends BaseDaoI<Adminloginrecord>{
	
}
