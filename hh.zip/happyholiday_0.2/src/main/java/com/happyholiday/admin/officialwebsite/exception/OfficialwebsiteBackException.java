package com.happyholiday.admin.officialwebsite.exception;

import org.aspectj.apache.bcel.ExceptionConstants;

public class OfficialwebsiteBackException extends Exception{

	public OfficialwebsiteBackException() {
		super();
	}


	public OfficialwebsiteBackException(String message) {
		super(message);
	}


}
