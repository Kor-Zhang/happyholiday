package com.happyholiday.admin.viewstickets.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.ViewticketViewsImgs;

public interface ViewsImgsDaoI extends BaseDaoI<ViewticketViewsImgs> {

}
