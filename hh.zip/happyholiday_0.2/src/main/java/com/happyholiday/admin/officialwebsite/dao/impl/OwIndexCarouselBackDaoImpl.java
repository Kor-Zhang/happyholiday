package com.happyholiday.admin.officialwebsite.dao.impl;

import org.springframework.stereotype.Repository;

import com.happyholiday.admin.officialwebsite.dao.OwIndexCarouselBackDaoI;
import com.happyholiday.dao.impl.BaseDaoImpl;
import com.happyholiday.model.OfficialwebsiteIndexCarousel;
@Repository(value="owIndexCarouselBackDao")
public class OwIndexCarouselBackDaoImpl extends BaseDaoImpl<OfficialwebsiteIndexCarousel> implements OwIndexCarouselBackDaoI{
	
}
