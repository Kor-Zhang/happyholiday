/**
 * 
 */
/**
 * @author Jhon
 *
 */
package com.happyholiday.admin.cars.dao.impl;