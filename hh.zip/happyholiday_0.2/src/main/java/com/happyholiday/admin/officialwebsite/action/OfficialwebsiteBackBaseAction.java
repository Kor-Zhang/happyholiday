package com.happyholiday.admin.officialwebsite.action;

import org.apache.struts2.convention.annotation.Namespace;

import com.happyholiday.action.AdminsBaseAction;
import com.happyholiday.admin.officialwebsite.OwBackStatic;
@Namespace(OwBackStatic.Ow_BACK_NAMESPACE)
public class OfficialwebsiteBackBaseAction extends AdminsBaseAction {
	
}
