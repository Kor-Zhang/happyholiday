package com.happyholiday.admin.dao.impl;

import org.springframework.stereotype.Repository;

import com.happyholiday.admin.dao.AdminUpdateRecordDaoI;
import com.happyholiday.dao.impl.BaseDaoImpl;
import com.happyholiday.model.Adminupdaterecord;
@Repository("adminUpdateRecordDao")
public class AdminUpdateRecordDaoImpl extends BaseDaoImpl<Adminupdaterecord> implements AdminUpdateRecordDaoI{
	
}
