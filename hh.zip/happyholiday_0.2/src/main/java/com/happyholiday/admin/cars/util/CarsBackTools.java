package com.happyholiday.admin.cars.util;

import com.happyholiday.admin.util.BackTools;

public class CarsBackTools extends BackTools{

}
