package com.happyholiday.admin.exception;

public class AdminUpdateRecordException extends Exception {

	public AdminUpdateRecordException() {
		super();
	}

	public AdminUpdateRecordException(String message) {
		super(message);
	}
	
}
