package com.happyholiday.admin.viewstickets.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.ViewticketTickets;

public interface ViewTicketsDaoI extends BaseDaoI<ViewticketTickets>{

}
