package com.happyholiday.admin.dao;

import java.io.Serializable;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.Adminupdaterecord;

public interface AdminUpdateRecordDaoI extends BaseDaoI<Adminupdaterecord>{
	
}
