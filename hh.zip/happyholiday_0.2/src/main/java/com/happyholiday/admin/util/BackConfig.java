package com.happyholiday.admin.util;

import java.util.Properties;

import com.happyholiday.util.PubConfig;

public class BackConfig extends PubConfig{
	
}
