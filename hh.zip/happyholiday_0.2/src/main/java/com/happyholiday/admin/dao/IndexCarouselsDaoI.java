package com.happyholiday.admin.dao;

import java.io.Serializable;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.Admins;
import com.happyholiday.model.Indexcarousels;

public interface IndexCarouselsDaoI extends BaseDaoI<Indexcarousels>{
	
}
