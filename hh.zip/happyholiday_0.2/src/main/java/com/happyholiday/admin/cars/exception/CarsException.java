package com.happyholiday.admin.cars.exception;

public class CarsException extends Exception {

	public CarsException() {
		super();
	}

	public CarsException(String message) {
		super(message);
	}
	
}
