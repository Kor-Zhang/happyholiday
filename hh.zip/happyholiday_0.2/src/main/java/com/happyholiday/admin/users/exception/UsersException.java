package com.happyholiday.admin.users.exception;

public class UsersException extends Exception {

	public UsersException() {
		super();
	}

	public UsersException(String message) {
		super(message);
	}
	
}
