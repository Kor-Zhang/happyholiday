package com.happyholiday.admin.exception;

public class SystemddlException extends Exception {

	public SystemddlException() {
		super();
	}

	public SystemddlException(String message) {
		super(message);
	}
}
