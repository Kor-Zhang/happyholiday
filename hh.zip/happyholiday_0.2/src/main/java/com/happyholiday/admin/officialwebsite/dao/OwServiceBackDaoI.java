package com.happyholiday.admin.officialwebsite.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.OfficialwebsiteIndexCarousel;
import com.happyholiday.model.OfficialwebsiteIndexDisplay;
import com.happyholiday.model.OfficialwebsiteNews;
import com.happyholiday.model.OfficialwebsiteService;

public interface OwServiceBackDaoI extends BaseDaoI<OfficialwebsiteService>{
	
}
