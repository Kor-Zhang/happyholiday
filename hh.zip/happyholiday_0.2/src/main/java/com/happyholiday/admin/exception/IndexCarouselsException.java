package com.happyholiday.admin.exception;

public class IndexCarouselsException extends Exception {

	public IndexCarouselsException() {
		super();
	}

	public IndexCarouselsException(String message) {
		super(message);
	}
	
}
