package com.happyholiday.admin.officialwebsite.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.OfficialwebsiteIndexCarousel;

public interface OwIndexCarouselBackDaoI extends BaseDaoI<OfficialwebsiteIndexCarousel>{
	
}
