package com.happyholiday.admin.cars.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.Carimgs;
import com.happyholiday.model.Cars;

public interface CarsDaoI extends BaseDaoI<Cars>{
	
}
