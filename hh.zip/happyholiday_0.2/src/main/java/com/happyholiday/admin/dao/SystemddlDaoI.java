package com.happyholiday.admin.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.Rentcarusers;
import com.happyholiday.model.Systemddl;

public interface SystemddlDaoI extends BaseDaoI<Systemddl>{

}
