package com.happyholiday.admin.cars.dao;

import java.io.Serializable;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.Admins;
import com.happyholiday.model.Recommendcars;

public interface RecommendCarsDaoI extends BaseDaoI<Recommendcars>{
	
}
