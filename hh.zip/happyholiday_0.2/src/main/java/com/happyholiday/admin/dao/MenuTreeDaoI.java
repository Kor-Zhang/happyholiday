package com.happyholiday.admin.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.Menutree;

public interface MenuTreeDaoI extends BaseDaoI<Menutree> {
	
}
