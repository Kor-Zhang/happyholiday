package com.happyholiday.admin.cars.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.Carimgs;
import com.happyholiday.model.Cars;
import com.happyholiday.model.Rentcarusers;

public interface RentCarUsersDaoI extends BaseDaoI<Rentcarusers>{
	
}
