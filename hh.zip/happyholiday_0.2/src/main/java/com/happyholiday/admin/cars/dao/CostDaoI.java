package com.happyholiday.admin.cars.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.Cost;

public interface CostDaoI extends BaseDaoI<Cost>{
	
}
