package com.happyholiday.admin.dao;

import java.io.Serializable;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.Admins;
import com.happyholiday.model.Carimgs;
import com.happyholiday.model.Imgs;

public interface ImgsDaoI extends BaseDaoI<Imgs>{
	
}
