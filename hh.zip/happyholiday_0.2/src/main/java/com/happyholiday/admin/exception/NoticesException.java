package com.happyholiday.admin.exception;

public class NoticesException extends Exception {

	public NoticesException() {
		super();
	}

	public NoticesException(String message) {
		super(message);
	}
	
}
