package com.happyholiday.admin.viewstickets.exception;
/**
 * 无权限异常
 * @author Kor_Zhang
 *
 */
public class NoManageViewTicketsPower extends Exception {

	public NoManageViewTicketsPower() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NoManageViewTicketsPower(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public NoManageViewTicketsPower(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NoManageViewTicketsPower(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NoManageViewTicketsPower(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
}
