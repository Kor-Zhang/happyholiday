package com.happyholiday.admin.users.dao;

import java.io.Serializable;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.Adminupdaterecord;
import com.happyholiday.model.Userupdaterecord;

public interface UserUpdateRecordDaoI extends BaseDaoI<Userupdaterecord>{
	
}
