package com.happyholiday.admin.officialwebsite.dao.impl;

import org.springframework.stereotype.Repository;

import com.happyholiday.admin.officialwebsite.dao.OwIndexDisplayBackDaoI;
import com.happyholiday.dao.impl.BaseDaoImpl;
import com.happyholiday.model.OfficialwebsiteIndexDisplay;
@Repository(value="owIndexDisplayBackDao")
public class OwIndexDisplayBackDaoImpl extends BaseDaoImpl<OfficialwebsiteIndexDisplay> implements OwIndexDisplayBackDaoI{
	
}
