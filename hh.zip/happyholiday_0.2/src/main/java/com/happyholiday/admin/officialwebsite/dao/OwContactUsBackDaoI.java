package com.happyholiday.admin.officialwebsite.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.OfficialwebsiteContactUs;


public interface OwContactUsBackDaoI extends BaseDaoI<OfficialwebsiteContactUs>{
	
}
