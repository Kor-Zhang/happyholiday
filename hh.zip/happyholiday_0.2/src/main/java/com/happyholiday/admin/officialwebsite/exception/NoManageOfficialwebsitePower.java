package com.happyholiday.admin.officialwebsite.exception;
/**
 * 无权限异常
 * @author Kor_Zhang
 *
 */
public class NoManageOfficialwebsitePower extends OfficialwebsiteBackException {

	public NoManageOfficialwebsitePower() {
		super();
	}

	public NoManageOfficialwebsitePower(String message) {
		super(message);
	}

	
	
}
