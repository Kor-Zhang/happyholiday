package com.happyholiday.admin.exception;

public class OrdersException extends Exception {

	public OrdersException() {
		super();
	}

	public OrdersException(String message) {
		super(message);
	}
	
}
