package com.happyholiday.admin.dao;

import java.io.Serializable;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.Admins;

public interface AdminsDaoI extends BaseDaoI<Admins>{
	
}
