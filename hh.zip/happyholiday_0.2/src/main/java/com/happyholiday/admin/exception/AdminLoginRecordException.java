package com.happyholiday.admin.exception;

public class AdminLoginRecordException extends Exception {

	public AdminLoginRecordException() {
		super();
	}

	public AdminLoginRecordException(String message) {
		super(message);
	}
	
}
