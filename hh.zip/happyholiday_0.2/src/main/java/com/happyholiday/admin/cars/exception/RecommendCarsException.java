package com.happyholiday.admin.cars.exception;

public class RecommendCarsException extends Exception {

	public RecommendCarsException() {
		super();
	}

	public RecommendCarsException(String message) {
		super(message);
	}
	
}
