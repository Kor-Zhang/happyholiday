package com.happyholiday.admin.officialwebsite.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.OfficialwebsiteIndexCarousel;
import com.happyholiday.model.OfficialwebsiteIndexDisplay;

public interface OwIndexDisplayBackDaoI extends BaseDaoI<OfficialwebsiteIndexDisplay>{
	
}
