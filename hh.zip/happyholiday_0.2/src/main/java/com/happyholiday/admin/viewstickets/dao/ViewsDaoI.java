package com.happyholiday.admin.viewstickets.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.ViewticketViews;

public interface ViewsDaoI extends BaseDaoI<ViewticketViews> {

}
