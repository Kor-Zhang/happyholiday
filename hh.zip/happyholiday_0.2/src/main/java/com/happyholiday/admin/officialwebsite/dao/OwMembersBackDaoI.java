package com.happyholiday.admin.officialwebsite.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.OfficialwebsiteIndexCarousel;
import com.happyholiday.model.OfficialwebsiteMembers;

public interface OwMembersBackDaoI extends BaseDaoI<OfficialwebsiteMembers>{
	
}
