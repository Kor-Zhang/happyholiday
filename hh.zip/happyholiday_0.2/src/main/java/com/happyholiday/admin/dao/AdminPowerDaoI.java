package com.happyholiday.admin.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.Adminpower;
import com.happyholiday.model.Orders;

public interface AdminPowerDaoI extends BaseDaoI<Adminpower>{
	
}
