package com.happyholiday.admin.viewstickets.pageModel;

public class PageViewImgs {
	private String id;
	private String viewId;
	private String imgId;
	private Boolean main;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

	public String getViewId() {
		return viewId;
	}
	public void setViewId(String viewId) {
		this.viewId = viewId;
	}
	public String getImgId() {
		return imgId;
	}
	public void setImgId(String imgId) {
		this.imgId = imgId;
	}
	public Boolean getMain() {
		return main;
	}
	public void setMain(Boolean main) {
		this.main = main;
	}
	
	
}
