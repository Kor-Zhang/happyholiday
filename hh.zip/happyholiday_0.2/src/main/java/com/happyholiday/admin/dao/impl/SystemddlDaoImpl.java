package com.happyholiday.admin.dao.impl;

import org.springframework.stereotype.Repository;

import com.happyholiday.admin.dao.SystemddlDaoI;
import com.happyholiday.dao.impl.BaseDaoImpl;
import com.happyholiday.model.Systemddl;
@Repository("systemddlDao")
public class SystemddlDaoImpl extends BaseDaoImpl<Systemddl> implements SystemddlDaoI{
	
}
 