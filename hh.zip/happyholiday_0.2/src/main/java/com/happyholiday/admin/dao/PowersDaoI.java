package com.happyholiday.admin.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.Powers;

public interface PowersDaoI extends BaseDaoI<Powers>{
	
}
