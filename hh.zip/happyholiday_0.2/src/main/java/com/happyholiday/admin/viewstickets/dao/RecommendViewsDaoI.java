package com.happyholiday.admin.viewstickets.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.ViewticketRecommendviews;

public interface RecommendViewsDaoI extends BaseDaoI<ViewticketRecommendviews>{

}
