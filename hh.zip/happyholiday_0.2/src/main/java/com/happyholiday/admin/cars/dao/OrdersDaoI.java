package com.happyholiday.admin.cars.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.Orders;

public interface OrdersDaoI extends BaseDaoI<Orders>{
	
}
