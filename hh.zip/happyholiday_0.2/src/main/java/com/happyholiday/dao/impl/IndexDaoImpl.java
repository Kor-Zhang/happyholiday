package com.happyholiday.dao.impl;

import org.springframework.stereotype.Repository;

import com.happyholiday.dao.IndexDaoI;
import com.happyholiday.model.Indexcarousels;
@Repository("indexDao")
public class IndexDaoImpl extends BaseDaoImpl<Indexcarousels>  implements IndexDaoI{
		
}
