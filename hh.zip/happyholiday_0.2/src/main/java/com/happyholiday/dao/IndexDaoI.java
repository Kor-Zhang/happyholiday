package com.happyholiday.dao;

import com.happyholiday.model.Indexcarousels;


public interface IndexDaoI extends BaseDaoI<Indexcarousels>{

}
