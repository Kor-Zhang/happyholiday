package com.happyholiday.front.viewstickets.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.ViewticketViews;

public interface ViewsDaoI extends BaseDaoI<ViewticketViews>{

}
