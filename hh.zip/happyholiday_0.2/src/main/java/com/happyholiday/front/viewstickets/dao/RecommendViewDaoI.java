package com.happyholiday.front.viewstickets.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.ViewticketRecommendviews;

public interface RecommendViewDaoI extends BaseDaoI<ViewticketRecommendviews>{

}
