package com.happyholiday.front.car.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.Recommendcars;

public interface RecommendCarsDaoI  extends BaseDaoI<Recommendcars>{

}
