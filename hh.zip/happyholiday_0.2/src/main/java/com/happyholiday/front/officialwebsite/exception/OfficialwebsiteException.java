package com.happyholiday.front.officialwebsite.exception;

public class OfficialwebsiteException extends Exception {

	public OfficialwebsiteException() {
		super();
	}

	public OfficialwebsiteException(String message) {
		super(message);
	}
	
}
