package com.happyholiday.front.car.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.Cost;

public interface CostDaoI  extends BaseDaoI<Cost>{

}
