/**
 * 
 */
/**
 * @author Jhon
 *
 */
package com.happyholiday.front.viewstickets.pageModel;