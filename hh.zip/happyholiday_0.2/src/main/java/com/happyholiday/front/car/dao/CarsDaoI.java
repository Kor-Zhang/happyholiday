package com.happyholiday.front.car.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.Cars;

public interface CarsDaoI extends BaseDaoI<Cars> {

}
