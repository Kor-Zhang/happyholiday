package com.happyholiday.front.car.dao;

import java.io.Serializable;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.Users;

public interface CarUsersDaoI extends BaseDaoI<Users>{
	
}
