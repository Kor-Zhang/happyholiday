package com.happyholiday.front.user.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.Userupdaterecord;

public interface UserUpdateRecordDaoI  extends BaseDaoI<Userupdaterecord>{

}
