package com.happyholiday.front.car.dao.impl;

import org.springframework.stereotype.Repository;

import com.happyholiday.front.car.dao.FrontSystemddlDaoI;
import com.happyholiday.dao.impl.BaseDaoImpl;
import com.happyholiday.model.Systemddl;
@Repository("frontSystemddlDao")
public class FrontSystemddlDaoImpl extends BaseDaoImpl<Systemddl> implements FrontSystemddlDaoI{
	
}
 