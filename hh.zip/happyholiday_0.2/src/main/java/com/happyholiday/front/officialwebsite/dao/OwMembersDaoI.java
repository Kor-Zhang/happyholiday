package com.happyholiday.front.officialwebsite.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.OfficialwebsiteIndexCarousel;
import com.happyholiday.model.OfficialwebsiteMembers;

public interface OwMembersDaoI extends BaseDaoI<OfficialwebsiteMembers>{
	
}
