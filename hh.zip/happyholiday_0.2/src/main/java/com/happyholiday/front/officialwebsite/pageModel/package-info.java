/**
 * 
 */
/**
 * @author Kor_Zhang
 *
 */
package com.happyholiday.front.officialwebsite.pageModel;