package com.happyholiday.front.officialwebsite.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.OfficialwebsiteIndexCarousel;

public interface OwIndexCarouselDaoI extends BaseDaoI<OfficialwebsiteIndexCarousel>{
	
}
