package com.happyholiday.front.viewstickets.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.ViewticketOrders;

public interface ViewOrderDaoI extends BaseDaoI<ViewticketOrders> {

}
