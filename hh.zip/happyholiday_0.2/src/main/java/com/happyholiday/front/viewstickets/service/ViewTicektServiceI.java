package com.happyholiday.front.viewstickets.service;

import com.happyholiday.front.viewstickets.pageModel.PageViewTickets;

public interface ViewTicektServiceI {
	 PageViewTickets getOneTicket(PageViewTickets pageModel) throws Exception;
}
