package com.happyholiday.front.viewstickets.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.ViewticketCarousels;

public interface ViewCarouselsDaoI extends BaseDaoI<ViewticketCarousels> {

}
