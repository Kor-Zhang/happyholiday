package com.happyholiday.front.user.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.Userloginrecord;

public interface UserLoginRecordDaoI extends BaseDaoI<Userloginrecord>{

}
