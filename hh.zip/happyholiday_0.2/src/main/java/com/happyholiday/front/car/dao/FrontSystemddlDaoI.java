package com.happyholiday.front.car.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.Rentcarusers;
import com.happyholiday.model.Systemddl;

public interface FrontSystemddlDaoI extends BaseDaoI<Systemddl>{

}
