package com.happyholiday.front.officialwebsite.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.OfficialwebsiteIndexCarousel;
import com.happyholiday.model.OfficialwebsiteIndexDisplay;

public interface OwIndexDisplayDaoI extends BaseDaoI<OfficialwebsiteIndexDisplay>{
	
}
