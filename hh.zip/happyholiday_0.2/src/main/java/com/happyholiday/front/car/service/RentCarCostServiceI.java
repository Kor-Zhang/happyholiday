package com.happyholiday.front.car.service;

import com.happyholiday.front.car.pageModel.PageRentCarCost;

public interface RentCarCostServiceI {
		void saveCarCostInfo(PageRentCarCost pageRentCarCost) throws Exception;
}
