package com.happyholiday.front.viewstickets.dao;

import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.ViewticketTickets;

public interface ViewTicketDaoI extends BaseDaoI<ViewticketTickets>{

}
