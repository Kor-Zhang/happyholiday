/**
 * 
 */
/**
 * @author Jhon
 *
 */
package com.happyholiday.front.officialwebsite.exception;