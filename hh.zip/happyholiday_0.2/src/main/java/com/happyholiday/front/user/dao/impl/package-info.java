/**
 * 
 */
/**
 * @author xiongcheng
 *
 */
package com.happyholiday.front.user.dao.impl;