/**
 * 
 */
/**
 * @author Jhon
 *
 */
package com.happyholiday.front.officialwebsite.model;