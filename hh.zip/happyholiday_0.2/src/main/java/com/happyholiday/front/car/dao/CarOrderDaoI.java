package com.happyholiday.front.car.dao;

import com.happyholiday.front.car.pageModel.PageOrder;
import com.happyholiday.dao.BaseDaoI;
import com.happyholiday.model.Orders;

public interface CarOrderDaoI extends BaseDaoI<Orders> {

}
